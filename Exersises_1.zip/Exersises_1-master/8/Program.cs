﻿Console .OutputEncoding = System.Text.Encoding.UTF8;
Console.Write("Nhập bán kính: ");
double r = double.Parse(Console.ReadLine());

double area = Math.PI * r * r;

Console.WriteLine("Diện tích hình tròn = " + area);