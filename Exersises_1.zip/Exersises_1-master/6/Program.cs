﻿Console.WriteLine("int: " + sizeof(int) + " bytes");
Console.WriteLine("double: " + sizeof(double) + " bytes");
Console.WriteLine("float: " + sizeof(float) + " bytes");
Console.WriteLine("char: " + sizeof(char) + " bytes");
Console.WriteLine("bool: " + sizeof(bool) + " bytes");