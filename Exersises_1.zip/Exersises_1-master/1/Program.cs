﻿using System;

class Program
{
    static void Main()
    {
        Console. OutputEncoding = System.Text.Encoding.UTF8;
        Console.Write("Nhập số thứ nhất: ");
        int a = int.Parse(Console.ReadLine());

        Console.Write("Nhập số thứ hai: ");
        int b = int.Parse(Console.ReadLine());

        int sum = a + b;

        Console.WriteLine("Tổng = " + sum);
    }
}
