﻿Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.Write("Nhập ký tự: ");
char ch = Console.ReadKey().KeyChar;

int ascii = (int)ch;

Console.WriteLine("\nASCII = " + ascii);
