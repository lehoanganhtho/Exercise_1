﻿Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.Write("Nhập số ngày: ");
int days = int.Parse(Console.ReadLine());

int years = days / 365;
int weeks = (days % 365) / 7;
int remainingDays = (days % 365) % 7;

Console.WriteLine($"{years} năm, {weeks} tuần, {remainingDays} ngày");
