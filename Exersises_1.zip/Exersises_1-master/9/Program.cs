﻿Console.OutputEncoding = System.Text.Encoding.UTF8;
Console.Write("Nhập cạnh: ");
double a = double.Parse(Console.ReadLine());
double S = a*a;
Console.WriteLine("Diện tích hình vuông =" + S);
